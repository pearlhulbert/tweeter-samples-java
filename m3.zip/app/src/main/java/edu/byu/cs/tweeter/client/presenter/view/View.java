package edu.byu.cs.tweeter.client.presenter.view;

public interface View {
    void displayMessage(String message);
}
